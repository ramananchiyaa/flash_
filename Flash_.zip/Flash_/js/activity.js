var FlashVieoPlayer = function(){
    var _this = this;

    this.init = function(){
        console.log("init Function");

        _this.captionTextArr = [
            {
                text : "Earlier in the programme we were talking to archaeologist",
                startTime : 1,
                endTime: 3
            },
            {
                text : "Dr Susan Clarke. She was telling us about Ötzi, the Stone Age man.",
                startTime : 4,
                endTime: 6
            },
            {
                text : "Some tourists found him while they were walking in the Alps.",
                startTime : 7,
                endTime: 9
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 10,
                endTime: 12
            },
            {
                text : "I found an interesting fossil.",
                startTime : 15,
                endTime: 18
            },
            {
                text : "What kind of fossil was it?",
                startTime : 20,
                endTime: 23
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 25,
                endTime: 27
            },
            {
                text : "A fish.",
                startTime : 29,
                endTime: 31
            },
            {
                text : "And how did you find it?",
                startTime : 33,
                endTime: 35
            },
            {
                text : "We were on a beach.",
                startTime : 37,
                endTime: 39
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 40,
                endTime: 42
            },
            {
                text : "My brother and I were playing with a ball near some cliffs, when I saw it.",
                startTime : 47,
                endTime: 50
            },
            {
                text : "What did you do with it?",
                startTime : 52,
                endTime: 57
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 60,
                endTime: 64
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 67,
                endTime: 69
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 71,
                endTime: 74
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 76,
                endTime: 78
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 82,
                endTime: 85
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 87,
                endTime: 90
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 92,
                endTime: 94
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 99,
                endTime: 100
            },
            {
                text : "Earlier in the programme we were talking to archaeologist",
                startTime : 101,
                endTime: 103
            },
            {
                text : "Dr Susan Clarke. She was telling us about Ötzi, the Stone Age man.",
                startTime : 104,
                endTime: 106
            },
            {
                text : "Some tourists found him while they were walking in the Alps.",
                startTime : 107,
                endTime: 109
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 110,
                endTime: 112
            },
            {
                text : "I found an interesting fossil.",
                startTime : 115,
                endTime: 118
            },
            {
                text : "What kind of fossil was it?",
                startTime : 120,
                endTime: 123
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 125,
                endTime: 127
            },
            {
                text : "A fish.",
                startTime : 129,
                endTime: 131
            },
            {
                text : "And how did you find it?",
                startTime : 133,
                endTime: 135
            },
            {
                text : "We were on a beach.",
                startTime : 137,
                endTime: 139
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 140,
                endTime: 142
            },
            {
                text : "My brother and I were playing with a ball near some cliffs, when I saw it.",
                startTime : 147,
                endTime: 150
            },
            {
                text : "What did you do with it?",
                startTime : 152,
                endTime: 157
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 160,
                endTime: 164
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 167,
                endTime: 169
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 171,
                endTime: 174
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime :176,
                endTime: 178
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 182,
                endTime: 185
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 187,
                endTime: 190
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 192,
                endTime: 194
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 199,
                endTime: 200
            },
            {
                text : "Earlier in the programme we were talking to archaeologist",
                startTime : 201,
                endTime: 203
            },
            {
                text : "Dr Susan Clarke. She was telling us about Ötzi, the Stone Age man.",
                startTime : 204,
                endTime: 206
            },
            {
                text : "Some tourists found him while they were walking in the Alps.",
                startTime : 207,
                endTime: 209
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 210,
                endTime: 212
            },
            {
                text : "I found an interesting fossil.",
                startTime : 215,
                endTime: 218
            },
            {
                text : "What kind of fossil was it?",
                startTime : 220,
                endTime: 223
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 225,
                endTime: 227
            },
            {
                text : "A fish.",
                startTime : 229,
                endTime: 231
            },
            {
                text : "And how did you find it?",
                startTime : 233,
                endTime: 235
            },
            {
                text : "We were on a beach.",
                startTime : 237,
                endTime: 239
            },
            {
                text : "Have you ever found anything interesting or unusual?",
                startTime : 240,
                endTime: 242
            },
            {
                text : "My brother and I were playing with a ball near some cliffs, when I saw it.",
                startTime : 247,
                endTime: 250
            },
            {
                text : "What did you do with it?",
                startTime : 252,
                endTime: 257
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 260,
                endTime: 264
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 267,
                endTime: 269
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 271,
                endTime: 274
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime :276,
                endTime: 278
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 282,
                endTime: 285
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 287,
                endTime: 290
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 292,
                endTime: 294
            },
            {
                text : "I took it home and I looked it up on the Internet.",
                startTime : 299,
                endTime: 300
            }
        ]

        _this.videoSrc = "assets/media/video/video1.mp4";

        _this.videoPlayer = $("#video");
        _this.play = $("#play");
        _this.sound = $("#sound");
        _this.next = $("#seek_next");
        _this.back = $("#seek_back");
        _this.subTitle = $("#subtitle");
        _this.activityPage = $('.activity');
        _this.videoPage = $('.videoPage');
        _this.submitBtn = $('#submit');
        _this.replayBtn = $('#replay');
        _this.ccBtn = $("#cc");
        _this.wrongFeebackBlock = $('#wrongFeedback');
        _this.questionBtn = $('#questionBtn');
        _this.revealText = $('#answer');
        _this.questionScreen = $('.questionScreen');
        _this.continueBtn = $('.continueBtn');
        _this.videoContainer = $('.vedio_Container');

        _this.currentTime = 0;
        _this.slidePosition = 0;
        _this.droppedItemsCount = 0;
        _this.tempVar = 0;
        _this.isCorrectlyDropped = false;
        _this.ccFlag = false;
        _this.submitSwitchFlag = false;
        _this.equalizeVideoTime = 0;

        _this.loadAssets();
    }

    this.loadAssets = function(){
        var preload = new createjs.LoadQueue();
        preload.addEventListener("fileload", _this.playVideo);
        preload.loadFile("assets/media/video/video1.mp4");
    }

    this.playVideo = function(){
        console.log(_this.videoPlayer);
        _this.questionScreen.hide();
        _this.videoPlayer[0].play();
        _this.totalDuration = _this.videoPlayer[0].duration;
        $('.preloaderScreen').hide();

        _this.addEvents();
    }

    this.addEvents = function(){

        _this.ccBtn.off("click").on("click",function(){
            if(!_this.ccFlag){
                _this.ccBtn.css('opacity','0.5');
                _this.ccFlag = true;
                _this.subTitle.hide();
                $("#cc").tooltip( "option", "content", "CCon" );
            }else{
                _this.ccBtn.css( 'opacity','1' );
                _this.ccFlag = false;
                _this.subTitle.show();
                $("#cc").tooltip( "option", "content", "CCoff" );
            }
        });

        _this.inter = setInterval(_this.runTheSlide,100);

        _this.play.off("click").on("click",function(){
            console.log("clicked");
            if(_this.videoPlayer[0].paused){
                _this.videoPlayer[0].play();
                _this.play.css({
                    "background":"url('assets/images/pause.png') no-repeat",
                    "background-size" :"100% 100%"
                });
                $("#play").tooltip( "option", "content", "Pause" );
            }else{
                _this.videoPlayer[0].pause();
                _this.play.css({
                    "background":"url('assets/images/play.png') no-repeat",
                    "background-size" :"100% 100%"
                });
                $("#play").tooltip( "option", "content", "Play" );
            }
        });

        _this.sound.off("click").on("click",function(){
            console.log("clicked");
            if(_this.videoPlayer[0].muted){
                _this.videoPlayer[0].muted = false;
                _this.sound.css('opacity','1');
                $("#sound").tooltip( "option", "content", "Mute" );
            }else{
                _this.videoPlayer[0].muted = true;
                _this.sound.css('opacity','0.5');
                $("#sound").tooltip( "option", "content", "Sound" );
            }
        });

        _this.next.off("click").on("click",function(){
            if( _this.currentTime <= _this.totalDuration-4){
                _this.currentTime = _this.currentTime + 5;
                _this.videoPlayer[0].currentTime = _this.currentTime;
            }
        });

        _this.back.off("click").on("click",function(){
            if( _this.currentTime >= 5){
                _this.currentTime = _this.currentTime - 5;
                _this.videoPlayer[0].currentTime = _this.currentTime;
            }
        });

        $( "#slider" ).slider({
            min: 0,
            max: 100,
            start: function(event,ui){
                console.log("Starting slide value is : ",ui.value);
                clearInterval(_this.inter);
            },
            slide: function(event,ui){
                _this.currentTime = ui.value * _this.totalDuration / 100;
                _this.videoPlayer[0].currentTime = _this.currentTime;
            },
            stop: function(event, ui){
                _this.slidePosition = _this.currentTime;
                console.log("Stop slide value is : ",ui.value);
                _this.inter = setInterval(_this.runTheSlide,100);
                if(ui.value == 100){
                    // $("#slider").slider('value',0);
                    // _this.subTitle.hide();
                    _this.openActivity();
                }
            }
        });

        $('.dragItem').draggable({
            appendTo: "body",
            containment : $('body'),
            start: function(){
                _this.isCorrectlyDropped = false;
                $(this).css('transition' , '0s');
            },
            drag: function(){
                //_this.submitBtn.css("pointer-events","none");
                $(this).css('z-index',1);
            },
            stop: function(){
                _this.revert(this);
                $(this).css('z-index',0);
                if(_this.isCorrectlyDropped){
                    console.log('Valid Drop');	
                }else{
                    console.log('Invalid Drop');
                }
            }
        });

        $('.dropItemHolder').droppable({
            drop: function(event,ui){
                _this.isCorrectlyDropped = true;
                _this.curDragElement = $(ui.draggable);
                _this.curDroppedElement = $(this);
                _this.appendElement();
            }
        });

        _this.submitBtn.off("click").on("click", function(){
            console.log("clicked on submit btn");
            if(!_this.submitSwitchFlag){
                for(let i=1; i<=6; i++){
                    let temp = $('#dropHolder'+i).children();
                    temp.css('color','green');
                    _this.submitBtn.text("Reset");
                    _this.submitSwitchFlag = true;
                    if( _this.droppedItemsCount == 0 ){
                        _this.wrongFeebackBlock.show();
                    }
                }
            }else{
                for(let i=1; i<=6; i++){
                    $('#'+i).appendTo($('#dragHolder'+i));
                    $('#'+i).css('color','black');
                }
                _this.wrongFeebackBlock.hide();
                _this.droppedItemsCount = 0;
                _this.submitSwitchFlag = false;
                _this.submitBtn.text("Submit");       
            }
        });

        _this.replayBtn.off("click").on("click",function(){
            _this.videoPlayer[0].currentTime = '0';
            _this.videoPlayer[0].play();
            _this.activityPage.hide();
            _this.videoPage.show();

            _this.play.css({
                "background":"url('assets/images/pause.png') no-repeat",
                "background-size" :"100% 100%"
            });
            _this.ccFlag = false;
            _this.ccBtn.css( 'opacity','1' );
            _this.videoPlayer[0].muted = false;
            _this.sound.css('opacity','1');
            $("#cc").tooltip( "option", "content", "CCoff" );
            $("#play").tooltip( "option", "content", "Pause" );
            $("#sound").tooltip( "option", "content", "Mute" );

            _this.videoPlayer[0].play();
            _this.inter = setInterval(_this.runTheSlide,100);
        });

        _this.questionBtn.off("click").on("click",function(){
            _this.revealText.toggle();
        });

        _this.continueBtn.off("click").on("click",function(){
            _this.questionScreen.hide();
            _this.videoPlayer[0].currentTime = 101;
            _this.equalizeVideoTime++;
            _this.videoPlayer[0].play();
        })

        _this.addToolTips();
    
    }

    this.revert = function(curElem){
        $(curElem).css({
            "top" : "0",
            "left" : "0",
            "right" : "0",
            "bottom" : "0",
            "transition" : "0.5s"
        });
    }

    this.appendElement = function(){
        let temp = _this.curDragElement.attr('id'),
            temp1 = _this.curDroppedElement.attr('id'),
            dropId = temp1.charAt(10);
            console.log(temp,dropId);
         if(temp == dropId){
            $(_this.curDragElement).appendTo(_this.curDroppedElement[0]);
            _this.droppedItemsCount++;
         }
    }

    this.runTheSlide = function(){
        if(!_this.videoPlayer[0].paused){
            _this.currentTime = _this.videoPlayer[0].currentTime;
            _this.slidePosition = _this.currentTime / _this.totalDuration * 100;
            $( "#slider" ).slider( "value" , _this.slidePosition);
            console.log(_this.currentTime,_this.totalDuration);
            for(let i=0; i<_this.captionTextArr.length; i++){
                if(Math.round(_this.currentTime) == _this.captionTextArr[i].startTime){
                    _this.subTitle.text(_this.captionTextArr[i].text);

                    //console.log("Subtitle found at : ",i);
                    _this.tempVar = i;
                }
            }

            if(Math.round(_this.currentTime) == 100){
                _this.videoPlayer[0].pause();
                _this.questionScreen.show();
            }

            if(Math.floor(_this.currentTime) == _this.captionTextArr[_this.tempVar].endTime){
                _this.subTitle.text("");
            }

            if(Math.round(_this.currentTime + _this.equalizeVideoTime) == Math.round(_this.totalDuration)){
                console.log("Video finished");
                _this.videoPlayer[0].pause();
                _this.play.css({
                    "background":"url('assets/images/play.png') no-repeat",
                    "background-size" :"100% 100%"
                });

                _this.currentTime = 0;
                _this.slidePosition = 0;
                $( "#slider" ).slider( "value", 0);
                clearInterval(_this.inter);

                setTimeout(_this.openActivity,1000);
            }
        }
    }

    this.openActivity = function(){
        _this.activityPage.show();
        _this.videoPage.hide();
    }

    this.addToolTips = function(){
        $("#cc").tooltip({
            content: "CCoff",
            position: {
                my: "center bottom-10",
                at: "right-20 top",
                using: function( position, feedback ) {
                  $( this ).css( position );
                  $( "<div>" )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
                }
              }
        });
        $("#sound").tooltip({ 
            position: {
                my: "center bottom-10",
                at: "right-20 top",
                using: function( position, feedback ) {
                  $( this ).css( position );
                  $( "<div>" )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
                }
              }
        });

        $("#seek_next").tooltip({ 
            position: {
                my: "center bottom-10",
                at: "right-15 top",
                using: function( position, feedback ) {
                  $( this ).css( position );
                  $( "<div>" )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
                }
              }
        });

        $("#play").tooltip({ 
            position: {
                my: "center bottom-10",
                at: "right-15 top",
                using: function( position, feedback ) {
                  $( this ).css( position );
                  $( "<div>" )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
                }
              }
        });

        $("#seek_back").tooltip({ 
            position: {
                my: "center bottom-10",
                at: "right-15 top",
                using: function( position, feedback ) {
                  $( this ).css( position );
                  $( "<div>" )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
                }
            }
        });


        // _this.next
        // _this.back
        // _this.play
    }
}